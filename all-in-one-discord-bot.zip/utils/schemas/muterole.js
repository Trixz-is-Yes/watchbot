module.exports = {
    _id: {
      role: String  
    }
}