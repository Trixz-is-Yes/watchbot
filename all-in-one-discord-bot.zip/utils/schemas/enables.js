module.exports = () => {
    cmd: {
        _id: Boolean
    }
}