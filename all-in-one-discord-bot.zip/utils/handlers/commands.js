const fs = require('fs')

module.exports = (client) => {
    fs.readdir('./commands/', (err, files) => {
        if (err) console.log(err);
    
        let jsFile = files.filter(f => f.split('.').pop() === 'js');
        if (jsFile.length <= 0) {
            return console.log('No commands')
        }
    
        jsFile.forEach((file, i) => {
            var pullCmd = require(`../../commands/${file}`);
            client.commands.set(pullCmd.config.name, pullCmd);

            console.log('Successfully loaded ' + pullCmd.config.name + ' command ', '<:wbCheck:874948797111861298>')

            if (!pullCmd.config.name) {
                console.log(`<:wbUnCheck:874948747459698689>  -> missing a help.name, or help.name is not a string.`)
            }
            if (!pullCmd.config.group) {
                console.log('<:wbUnCheck:874948747459698689> -> Couldn\'t find any group in ' + pullCmd.config.name)
                return;
        
            } else {
                if (!client.groups.includes(pullCmd.config.group)) {
                    return console.log('<:wbUnCheck:874948747459698689> -> Unknown group ' + `${pullCmd.config.group} in ` + pullCmd.config.name)
                }
            }
            try {
            pullCmd.config.aliases.forEach(alias => {
                client.aliases.set(alias, pullCmd.config.name);
            });
        } catch {
            
        }
    
        });
    });
}